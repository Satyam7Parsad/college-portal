To use your custom background image from Freepik:

1. Download the image from: https://www.freepik.com/free-vector/minimalist-gradient-background-design-template_34009211.htm

2. Save the downloaded image as "background-image.jpg" in this assets folder

3. The website will automatically use your image as the background

Current file should be named: background-image.jpg
Location: /Users/imaging/StudentPortal/assets/background-image.jpg